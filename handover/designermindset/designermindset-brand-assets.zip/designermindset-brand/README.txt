Designer Mindset brand assets

The live guidelines, always up to date: https://crucial.design/handover/designermindset
Fonts are not included. Get them from the links on that page.

Made by Crucial.Design
